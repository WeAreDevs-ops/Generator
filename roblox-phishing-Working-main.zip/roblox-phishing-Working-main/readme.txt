Listen up

Termed speaking here.

1. this is a source code i found on discord it was broken and all
2. i didn't "fully fix this source code" i only fixed apis, changed login page, removed some files, added some files, did a few changes in the embed of login and 2step page and notifier
3. i dont really know who the original creator of this "full source code" is, but credits to him for making this, dont forget to give me credits for fixing 😓.
4. if u want to change the background, go to the folder named "css" and remove back.gif then upload ur background gif and name it "back.gif" and done.

# enjoy this working fixed roblox phishing source code i guess.

Need help setting up, join https://discord.gg/9yz9ye23Ku
